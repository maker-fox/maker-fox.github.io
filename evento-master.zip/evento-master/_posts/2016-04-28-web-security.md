---
layout: post

#event information
title:  "Web Security"
cover: "http://rack.2.mshcdn.com/media/ZgkyMDEyLzEyLzA0L2JiLzl0aGluZ3NidXNpLmNZbi5qcGcKcAl0aHVtYgkxMjAweDYyNyMKZQlqcGc/5d927a64/abc/9-things-businesses-need-to-know-about-web-security-e5e7ae36a9.jpg"
date:   2016-04-03
start_time: "10:00"
end_time: "17:00"

#event organiser details
organiser: "Frank Smith"


---

Its very important that we keep up to date with web security. This talk will be a 7 hour introduction into the latest techniques about web security
and how we can keep our data safe across Mobiles, Desktops and Tablets.

Let me know if you would like to attend.
